# Anima-TestGrade
 Anima, Russell Allen Grade testing program

    Install Flask in order to use it in the browser, go to command prompt in the terminal in VS Code.
    By installing, type "pip install Flask".
    Next is to type the python file to test the program "python test-grade.py(python file).
    it will generate the link in the terminal and click the link by pressing CTRL + Left click or simply copy the url.
    After getting the Link, you can now use the program.